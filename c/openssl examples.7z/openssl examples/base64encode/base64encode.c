//base64_encode.c
#include <stdio.h>
#include <openssl/pem.h>

/* A BASE-64 ENCODER USING OPENSSL (by Len Schulwitz)
 * Parameter 1: A pointer to the data you want to base-64 encode.
 * Parameter 2: The number of bytes you want encoded.
 * Return: A character pointer to the base-64 encoded data (null-terminated for string output).
 * On linux, compile with "gcc base64_encode.c -o b64enc -lcrypto" and run with "./b64enc".
 * This software has no warranty and is provided "AS IS".  Use at your own risk.
 */

/*This function will Base-64 encode your data.*/
char * base64encode (const void *b64_encode_me, int encode_this_many_bytes) {
    BIO *b64_bio, *mem_bio;   //Declare two BIOs.  One base64 encodes, the other stores memory.
    BUF_MEM *mem_bio_mem_ptr; //Pointer to the "memory BIO" structure holding the base64 data.

    b64_bio = BIO_new(BIO_f_base64());  //Initialize our base64 filter BIO.
    mem_bio = BIO_new(BIO_s_mem());  //Initialize our memory sink BIO.
    BIO_push(b64_bio, mem_bio);  //Link the BIOs (i.e. create a filter-sink BIO chain.)
    BIO_set_flags(b64_bio, BIO_FLAGS_BASE64_NO_NL);  //Don't add a newline every 64 characters.

    BIO_write(b64_bio, b64_encode_me, encode_this_many_bytes); //Encode and write our b64 data.
    BIO_flush(b64_bio);  //Flush data.  Necessary for b64 encoding, because of pad characters.

    BIO_get_mem_ptr(mem_bio, &mem_bio_mem_ptr);  //Store address of mem_bio's memory structure.
    BIO_set_close(mem_bio,BIO_NOCLOSE); //Permit access to mem_ptr after BIOs are destroyed.
    BIO_free_all(b64_bio);  //Destroys all BIOs in chain, starting with b64 (i.e. the 1st one).

    (*mem_bio_mem_ptr).data[(*mem_bio_mem_ptr).length] = '\0';  //Adds a null-terminator.

    return (*mem_bio_mem_ptr).data; //Returns base-64 encoded data. (See: "buf_mem_st" struct).
}

/*Example of how one might use the base64encode() function to base-64 encode some data.*/
int main(void) {
    char data_to_encode[] = "Encode Me!";  //A null terminated string to be base-64 encoded.
    int bytes_to_encode = sizeof(data_to_encode) - 1; //Number of bytes in string (minus null).
    char * base64data = base64encode(data_to_encode, bytes_to_encode);  //Base-64 encodes data.

    printf("Original character string is: %s\n", data_to_encode);  //Prints our initial string.
    printf("Base-64 encoded string is: %s\n", base64data);  //Prints our Base64 encoded string.

    free(base64data);  //Frees up the memory holding our base64 encoded data.
	
	getchar();
	return 0;
}