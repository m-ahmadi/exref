<?php
$str = "ydokynd7NiKCn6fvv8za5g==";
$suffix = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

echo $t = sha1($str.$suffix, false);
echo "\n";
echo $accept = base64_encode( sha1("y9npEspxzUlo1sUNBipVtA==258EAFA5-E914-47DA-95CA-C5AB0DC85B11", true) );
?>