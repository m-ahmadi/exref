#include <stdio.h>
#include <string.h>
#include <openssl/sha.h>

// 258EAFA5-E914-47DA-95CA-C5AB0DC85B11

int main () {
	char data[] = "gAoqwNV37mhIIyeGVqj9rA==";
	unsigned char hash[SHA_DIGEST_LENGTH];
	
	SHA1( (unsigned char*)&data, strlen(data), (unsigned char*)&hash );
	printf("%s", hash);
	
	getchar();
	return 0;
}


/*
	// The data to be hashed
	char data[] = "gAoqwNV37mhIIyeGVqj9rA==";
	size_t length = sizeof(data);
	unsigned char hash[SHA_DIGEST_LENGTH];
	SHA1(data, length, hash);
	// hash now contains the 20-byte SHA-1 hash
*/