#include <stdio.h>
#include <string.h>
#include "bio.h"
#include "evp.h"
#include "applink.c"
BIO_METHOD *   BIO_f_base64(void);

int main() {
	BIO * bio, * b64;
	char message[] = "Hello World \n\n";
	b64 = BIO_new( BIO_f_base64() );
	bio = BIO_new_fp(stdout, BIO_NOCLOSE);
	BIO_push(b64, bio);
	BIO_write(b64, message, strlen(message));
	BIO_flush(b64);
	BIO_free_all(b64);
	
	getchar();
	return 0;
}