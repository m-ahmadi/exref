#include <stdio.h>
#include <string.h>
#include <openssl/sha.h>

#define KEY_SUFFIX "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
#define DATA T0wBdG7epLzzBXI2rnD5rA==


int main() {

	unsigned char digest[SHA_DIGEST_LENGTH];
	char string[] = "T0wBdG7epLzzBXI2rnD5rA==";
	char mdString[SHA_DIGEST_LENGTH*2+1];
	int i;

	SHA1((unsigned char*)&string, strlen(string), (unsigned char*)&digest);    
	
	for(i = 0; i < SHA_DIGEST_LENGTH; i++) {
		sprintf(&mdString[i*2], "%02x", (unsigned int)digest[i]);
	}
 
    printf("SHA1 digest: %s\n", mdString);
	
	getchar();
	return 0;
}